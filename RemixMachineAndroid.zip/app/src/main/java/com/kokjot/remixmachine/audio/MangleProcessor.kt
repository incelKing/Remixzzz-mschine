package com.kokjot.remixmachine.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Offline (non-real-time) mangling for a short voice-note recording.
 * Everything here runs as a straight loop over the whole sample array --
 * no audio callback, no real-time constraints -- which is exactly why
 * this is a good first DSP milestone in pure Kotlin (see the project
 * README's phased roadmap). The individual effects are the same ideas as
 * the web prototype's CURSED mode: bitcrush, sample-and-hold, buffer
 * stutter, and ring modulation, applied here to a spoken voice clip
 * instead of a sliced music loop.
 */
object MangleProcessor {

    /** Absolute cap on the output length, regardless of how much the
     *  stutter effect grows the material -- a safety net, not a target. */
    private const val MAX_OUTPUT_SECONDS = 30

    /**
     * Removes near-silent stretches (pauses/dead air) from [samples], then
     * runs the result through a hard mangle chain. [intensity] is 0..1;
     * the request that motivated this feature was "mangle it HARD," so the
     * caller should default this high (see VoiceNoteScreen's default of
     * 0.8) rather than treating 0.5 as a sensible middle default.
     */
    fun process(samples: ShortArray, sampleRate: Int, intensity: Double): ShortArray {
        if (samples.isEmpty()) return samples
        val gapless = removeGaps(samples, sampleRate)
        val mangled = mangleHard(gapless, sampleRate, intensity.coerceIn(0.0, 1.0))
        val maxSamples = sampleRate * MAX_OUTPUT_SECONDS
        return if (mangled.size > maxSamples) mangled.copyOf(maxSamples) else mangled
    }

    // ---------------------------------------------------------------
    // Gap removal
    // ---------------------------------------------------------------

    /**
     * Splices out any stretch of audio whose short-time RMS stays below
     * [silenceThreshold] for a full analysis window, concatenating what's
     * left with a short fade at each kept segment's edges so the splice
     * points don't click. This is "get rid of the empty gaps" -- pauses
     * are cut out entirely rather than filled with something else, so a
     * 10-second recording with lots of dead air can mangle down into a
     * much shorter, relentlessly dense clip.
     */
    fun removeGaps(samples: ShortArray, sampleRate: Int, silenceThreshold: Double = 0.02): ShortArray {
        val windowSize = (sampleRate * 0.02).toInt().coerceAtLeast(1) // 20ms analysis windows
        val fadeLen = (sampleRate * 0.005).toInt().coerceAtLeast(1)   // 5ms click-guard fade

        val numWindows = (samples.size + windowSize - 1) / windowSize
        val loud = BooleanArray(numWindows)
        for (w in 0 until numWindows) {
            val start = w * windowSize
            val end = min(start + windowSize, samples.size)
            var sumSq = 0.0
            for (j in start until end) {
                val v = samples[j] / 32768.0
                sumSq += v * v
            }
            val rms = sqrt(sumSq / (end - start))
            loud[w] = rms > silenceThreshold
        }

        data class Seg(val start: Int, val end: Int)
        val segments = mutableListOf<Seg>()
        var w = 0
        while (w < numWindows) {
            if (loud[w]) {
                val segStartWindow = w
                while (w < numWindows && loud[w]) w++
                val start = segStartWindow * windowSize
                val end = min(w * windowSize, samples.size)
                segments.add(Seg(start, end))
            } else {
                w++
            }
        }

        // if literally everything was below threshold (e.g. a very quiet
        // recording), bail out and mangle the original rather than return
        // silence
        if (segments.isEmpty()) return samples

        val totalLen = segments.sumOf { it.end - it.start }
        val out = ShortArray(totalLen)
        var pos = 0
        for (seg in segments) {
            val len = seg.end - seg.start
            for (j in 0 until len) {
                out[pos + j] = samples[seg.start + j]
            }
            val fadeIn = min(fadeLen, len)
            for (j in 0 until fadeIn) {
                val g = j.toDouble() / fadeIn
                out[pos + j] = (out[pos + j] * g).toInt().toShort()
            }
            val fadeOut = min(fadeLen, len)
            for (j in 0 until fadeOut) {
                val idx = pos + len - 1 - j
                val g = j.toDouble() / fadeOut
                out[idx] = (out[idx] * g).toInt().toShort()
            }
            pos += len
        }
        return out
    }

    // ---------------------------------------------------------------
    // Mangle chain
    // ---------------------------------------------------------------

    private fun mangleHard(input: ShortArray, sampleRate: Int, intensity: Double): ShortArray {
        var buf = input
        buf = bitcrush(buf, levels = lerp(220.0, 10.0, intensity).toInt().coerceAtLeast(2))
        buf = sampleHold(buf, factor = lerp(1.0, 7.0, intensity).toInt().coerceAtLeast(1))
        buf = stutterGlitch(buf, sampleRate, chance = lerp(0.08, 0.55, intensity))
        buf = ringModulate(buf, sampleRate, carrierHz = 80.0 + intensity * 140.0, depth = intensity * 0.85)
        buf = normalizeToPeak(buf, ceilingDb = -1.0)
        return buf
    }

    private fun lerp(a: Double, b: Double, t: Double): Double = a + (b - a) * t

    /** Bit-depth reduction: quantize each sample to a smaller set of levels. */
    private fun bitcrush(samples: ShortArray, levels: Int): ShortArray {
        val step = 65536.0 / levels
        return ShortArray(samples.size) { i ->
            val v = samples[i].toDouble()
            (round(v / step) * step).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    /** Sample-rate reduction via sample-and-hold. */
    private fun sampleHold(samples: ShortArray, factor: Int): ShortArray {
        if (factor <= 1) return samples
        val out = ShortArray(samples.size)
        var held: Short = 0
        for (i in samples.indices) {
            if (i % factor == 0) held = samples[i]
            out[i] = held
        }
        return out
    }

    /** Randomly repeats small chunks in place, like a scratched CD. */
    private fun stutterGlitch(samples: ShortArray, sampleRate: Int, chance: Double): ShortArray {
        val chunk = (sampleRate * 0.05).toInt().coerceAtLeast(1) // ~50ms chunks
        val out = ArrayList<Short>(samples.size + sampleRate)
        val rnd = Random(System.nanoTime())
        var i = 0
        while (i < samples.size) {
            val end = min(i + chunk, samples.size)
            if (rnd.nextDouble() < chance) {
                val repeats = 2 + rnd.nextInt(4) // 2-5 repeats
                repeat(repeats) {
                    for (j in i until end) out.add(samples[j])
                }
            } else {
                for (j in i until end) out.add(samples[j])
            }
            i = end
        }
        return out.toShortArray()
    }

    /** Multiplies the signal by a sine carrier -- true ring modulation. */
    private fun ringModulate(samples: ShortArray, sampleRate: Int, carrierHz: Double, depth: Double): ShortArray {
        val out = ShortArray(samples.size)
        for (i in samples.indices) {
            val t = i.toDouble() / sampleRate
            val carrier = sin(2.0 * PI * carrierHz * t)
            val dry = samples[i].toDouble()
            val wet = dry * carrier
            val mixed = dry * (1 - depth) + wet * depth
            out[i] = mixed.toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    /** Brings the loudest sample up to [ceilingDb] (negative dBFS) without clipping. */
    private fun normalizeToPeak(samples: ShortArray, ceilingDb: Double): ShortArray {
        var peak = 1
        for (s in samples) {
            val a = abs(s.toInt())
            if (a > peak) peak = a
        }
        val ceiling = 32767.0 * 10.0.pow(ceilingDb / 20.0)
        val gain = ceiling / peak
        return ShortArray(samples.size) { i ->
            (samples[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
        }
    }
}
