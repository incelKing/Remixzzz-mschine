package com.kokjot.remixmachine.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.kokjot.remixmachine.audio.MangleProcessor
import com.kokjot.remixmachine.audio.PcmPlayer
import com.kokjot.remixmachine.audio.VoiceRecorder
import com.kokjot.remixmachine.audio.WavExporter
import com.kokjot.remixmachine.ui.theme.NeonCyan
import com.kokjot.remixmachine.ui.theme.NeonGreen
import com.kokjot.remixmachine.ui.theme.NeonRed
import com.kokjot.remixmachine.ui.theme.Panel
import com.kokjot.remixmachine.ui.theme.PanelEdge
import com.kokjot.remixmachine.ui.theme.TextDim
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs
import kotlin.math.min

private enum class Stage { IDLE, RECORDING, RECORDED, MANGLING, READY }

private const val SAMPLE_RATE = 44100

@Composable
fun VoiceNoteScreen() {
    val context = LocalContext.current

    var stage by remember { mutableStateOf(Stage.IDLE) }
    var rawSamples by remember { mutableStateOf<ShortArray?>(null) }
    var mangledSamples by remember { mutableStateOf<ShortArray?>(null) }
    var recordSecondsElapsed by remember { mutableStateOf(0f) }
    var mangleIntensity by remember { mutableStateOf(0.8f) } // "hard" default, not a neutral 0.5
    var isPlaying by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("Tap Record — up to 10 seconds.") }

    val recorder = remember { VoiceRecorder(SAMPLE_RATE) }
    val player = remember { PcmPlayer() }

    fun beginRecording() {
        stage = Stage.RECORDING
        recordSecondsElapsed = 0f
        mangledSamples = null
        recorder.start { finished ->
            rawSamples = finished
            stage = if (finished.isEmpty()) Stage.IDLE else Stage.RECORDED
            statusText = if (finished.isEmpty())
                "Recording failed — try again."
            else
                "Got ${"%.1f".format(finished.size.toFloat() / SAMPLE_RATE)}s. Ready to mangle."
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            beginRecording()
        } else {
            statusText = "Microphone permission is required to record a voice note."
        }
    }

    // recording countdown -- independent of the raw sample-counting inside
    // VoiceRecorder, purely for the UI progress ring
    LaunchedEffect(stage) {
        if (stage == Stage.RECORDING) {
            val start = System.currentTimeMillis()
            while (stage == Stage.RECORDING) {
                val elapsed = (System.currentTimeMillis() - start) / 1000f
                recordSecondsElapsed = min(elapsed, VoiceRecorder.MAX_DURATION_SECONDS.toFloat())
                if (elapsed >= VoiceRecorder.MAX_DURATION_SECONDS) {
                    recorder.stop()
                    break
                }
                delay(50)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "VOICE NOTE MODE",
            color = NeonGreen,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp
        )
        Text(
            "record \u2192 mangle hard \u2192 no gaps",
            color = TextDim,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        Text(statusText, color = NeonCyan, fontSize = 12.sp, modifier = Modifier.padding(bottom = 16.dp))

        // waveform preview of whichever buffer is most relevant right now
        val displayed = mangledSamples ?: rawSamples
        WaveformPreview(
            samples = displayed,
            color = if (mangledSamples != null) NeonGreen else TextDim,
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
                .background(Panel)
                .padding(4.dp)
        )

        Spacer(Modifier.height(24.dp))

        when (stage) {
            Stage.IDLE, Stage.RECORDED, Stage.READY -> {
                Button(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) {
                            beginRecording()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed)
                ) { Text(if (stage == Stage.IDLE) "\uD83C\uDF99\uFE0F RECORD" else "\uD83C\uDF99\uFE0F RE-RECORD") }
            }
            Stage.RECORDING -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LinearProgressIndicator(
                        progress = { recordSecondsElapsed / VoiceRecorder.MAX_DURATION_SECONDS },
                        modifier = Modifier.width(220.dp),
                        color = NeonRed,
                        trackColor = PanelEdge
                    )
                    Text(
                        "${"%.1f".format(recordSecondsElapsed)}s / ${VoiceRecorder.MAX_DURATION_SECONDS}s",
                        color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { recorder.stop() }) { Text("STOP EARLY") }
                }
            }
            Stage.MANGLING -> {
                CircularProgressIndicator(color = NeonGreen)
                Text("Mangling...", color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }

        if (stage == Stage.RECORDED || stage == Stage.READY) {
            Spacer(Modifier.height(20.dp))
            Text(
                "MANGLE INTENSITY  ${(mangleIntensity * 100).toInt()}%",
                color = TextDim, fontSize = 10.sp, letterSpacing = 1.sp
            )
            Slider(
                value = mangleIntensity,
                onValueChange = { mangleIntensity = it },
                colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen),
                modifier = Modifier.width(260.dp)
            )

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val src = rawSamples ?: return@Button
                    stage = Stage.MANGLING
                    // MangleProcessor.process is pure computation (no I/O), so a
                    // short clip (<=10s raw) processes fast enough to run
                    // synchronously here; if you extend this to longer clips,
                    // move this to a coroutine on Dispatchers.Default instead.
                    val result = MangleProcessor.process(src, SAMPLE_RATE, mangleIntensity.toDouble())
                    mangledSamples = result
                    stage = Stage.READY
                    statusText = "Mangled: ${"%.1f".format(result.size.toFloat() / SAMPLE_RATE)}s of no-gaps chaos."
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen)
            ) { Text("\uD83D\uDD25 MANGLE IT", color = Color.Black, fontWeight = FontWeight.Bold) }
        }

        if (stage == Stage.READY) {
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = {
                        val samples = mangledSamples ?: return@Button
                        if (isPlaying) {
                            player.stop()
                            isPlaying = false
                        } else {
                            isPlaying = true
                            player.play(samples, SAMPLE_RATE) { isPlaying = false }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) { Text(if (isPlaying) "\u23F9 STOP" else "\u25B6 PLAY", color = Color.Black) }

                OutlinedButton(onClick = {
                    val samples = mangledSamples ?: return@OutlinedButton
                    val dir = context.getExternalFilesDir("Music")
                    if (dir != null && !dir.exists()) dir.mkdirs()
                    val file = File(dir, "voice_note_mangled_${System.currentTimeMillis()}.wav")
                    WavExporter.writeWav(samples, SAMPLE_RATE, file)
                    val uri = FileProvider.getUriForFile(
                        context, "${context.packageName}.fileprovider", file
                    )
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "audio/wav"
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(android.content.Intent.createChooser(intent, "Save / share voice note"))
                }) { Text("\uD83D\uDCBE SAVE / SHARE") }
            }
        }
    }
}

@Composable
private fun WaveformPreview(samples: ShortArray?, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (samples == null || samples.isEmpty()) return@Canvas
        val columns = 120
        val chunk = (samples.size / columns).coerceAtLeast(1)
        val w = size.width
        val h = size.height
        val colWidth = w / columns
        for (c in 0 until columns) {
            val start = c * chunk
            if (start >= samples.size) break
            val end = min(start + chunk, samples.size)
            var peak = 0
            for (j in start until end) {
                val a = abs(samples[j].toInt())
                if (a > peak) peak = a
            }
            val amp = (peak / 32768f).coerceIn(0f, 1f)
            val barHeight = (amp * h).coerceAtLeast(2f)
            val x = c * colWidth
            drawLine(
                color = color,
                start = Offset(x, h / 2 - barHeight / 2),
                end = Offset(x, h / 2 + barHeight / 2),
                strokeWidth = colWidth * 0.7f,
                cap = StrokeCap.Round
            )
        }
    }
}
