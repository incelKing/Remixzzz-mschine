package com.kokjot.remixmachine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.kokjot.remixmachine.ui.VoiceNoteScreen
import com.kokjot.remixmachine.ui.theme.RemixMachineTheme

/**
 * Phase-0 scaffold: this Activity currently hosts Voice Note Mode only.
 * As the rewrite progresses through the phases described in README.md,
 * this becomes a real navigation host (Tracks / Pattern / Song / Mixer /
 * Cursed / Export, matching the web app's tabs) with Voice Note Mode as
 * one screen among several rather than the whole app.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RemixMachineTheme {
                VoiceNoteScreen()
            }
        }
    }
}
