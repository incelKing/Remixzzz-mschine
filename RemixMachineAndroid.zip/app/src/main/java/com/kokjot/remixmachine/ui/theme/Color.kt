package com.kokjot.remixmachine.ui.theme

import androidx.compose.ui.graphics.Color

// Same palette as the web prototype's industrial-neon look
val BgVoid = Color(0xFF0A0D0B)
val Panel = Color(0xFF121712)
val PanelEdge = Color(0xFF243128)
val NeonGreen = Color(0xFF39FF6A)
val NeonCyan = Color(0xFF00E5FF)
val NeonYellow = Color(0xFFFFE600)
val NeonRed = Color(0xFFFF3B5C)
val TextDim = Color(0xFF7A9484)
val TextBright = Color(0xFFE8FFF0)
