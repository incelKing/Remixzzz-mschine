package com.kokjot.remixmachine.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper

/**
 * Plays a short in-memory PCM clip via a static-mode AudioTrack -- the
 * right tool for a one-shot clip under ~30s (streaming mode is for
 * longer/continuous playback, which is not what a mangled voice note is).
 */
class PcmPlayer {

    private var track: AudioTrack? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun play(samples: ShortArray, sampleRate: Int, onComplete: () -> Unit = {}) {
        stop()
        if (samples.isEmpty()) {
            onComplete()
            return
        }

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf, samples.size * 2)

        val newTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufBytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        newTrack.write(samples, 0, samples.size)
        newTrack.setNotificationMarkerPosition(samples.size)
        newTrack.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) {
                // defensively hop back to the main thread -- callers use this
                // to update Compose state, which must happen on the main thread
                mainHandler.post { onComplete() }
            }
            override fun onPeriodicNotification(t: AudioTrack?) {
                // unused
            }
        })

        track = newTrack
        newTrack.play()
    }

    fun stop() {
        track?.let {
            try {
                it.stop()
            } catch (e: IllegalStateException) {
                // already stopped/never started -- fine, we're releasing it regardless
            }
            it.release()
        }
        track = null
    }
}
