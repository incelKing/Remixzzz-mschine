package com.kokjot.remixmachine.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RemixMachineColorScheme = darkColorScheme(
    primary = NeonGreen,
    secondary = NeonCyan,
    tertiary = NeonYellow,
    error = NeonRed,
    background = BgVoid,
    surface = Panel,
    onBackground = TextBright,
    onSurface = TextBright,
    outline = PanelEdge
)

@Composable
fun RemixMachineTheme(
    // dark-only for now (matches the web app's identity); kept as a
    // parameter so this is one line to change if that ever varies
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RemixMachineColorScheme,
        content = content
    )
}
