package com.kokjot.remixmachine.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper

/**
 * Records raw mono 16-bit PCM from the microphone, hard-capped at
 * [MAX_DURATION_SECONDS]. Recording happens on a background thread;
 * [onFinished] is called back with the captured samples once recording
 * stops (either because [stop] was called, or the cap was reached) --
 * always posted back to the main thread, since callers use it to update
 * Compose UI state, which must not be touched from a background thread.
 *
 * This is the Phase-0 "pure Kotlin, no NDK" approach recommended for
 * getting the whole pipeline working before ever touching C++/Oboe --
 * see the project README for where this sits in the larger rewrite plan.
 */
class VoiceRecorder(private val sampleRate: Int = 44100) {

    companion object {
        const val MAX_DURATION_SECONDS = 10
    }

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var isRecording = false

    val maxSamples: Int get() = sampleRate * MAX_DURATION_SECONDS

    /** True while actively recording. Safe to poll from the UI thread. */
    fun isActive(): Boolean = isRecording

    @SuppressLint("MissingPermission") // caller is responsible for requesting RECORD_AUDIO first
    fun start(onFinished: (ShortArray) -> Unit) {
        if (isRecording) return

        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val readChunkSize = maxOf(minBuf, 2048)

        val record = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            readChunkSize * 4
        )

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            mainHandler.post { onFinished(ShortArray(0)) }
            return
        }

        audioRecord = record
        val collected = ShortArray(maxSamples)
        var written = 0

        isRecording = true
        record.startRecording()

        recordingThread = Thread {
            val chunk = ShortArray(readChunkSize)
            while (isRecording && written < maxSamples) {
                val read = record.read(chunk, 0, chunk.size)
                if (read > 0) {
                    val toCopy = minOf(read, maxSamples - written)
                    System.arraycopy(chunk, 0, collected, written, toCopy)
                    written += toCopy
                    if (written >= maxSamples) isRecording = false
                }
            }
            try {
                record.stop()
            } catch (e: IllegalStateException) {
                // stop() can throw if the record never successfully started running;
                // harmless here, we're tearing it down either way
            }
            record.release()
            audioRecord = null
            val result = collected.copyOf(written)
            mainHandler.post { onFinished(result) }
        }
        recordingThread?.start()
    }

    /** Ends recording early. The [onFinished] callback passed to [start] still fires. */
    fun stop() {
        isRecording = false
    }
}
