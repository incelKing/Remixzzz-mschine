package com.kokjot.remixmachine.audio

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Writes mono 16-bit PCM samples out as a standard WAV file. */
object WavExporter {

    fun writeWav(samples: ShortArray, sampleRate: Int, outFile: File) {
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * bitsPerSample / 8
        val blockAlign = numChannels * bitsPerSample / 8
        val dataSize = samples.size * 2
        val chunkSize = 36 + dataSize

        FileOutputStream(outFile).use { fos ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray(Charsets.US_ASCII))
            header.putInt(chunkSize)
            header.put("WAVE".toByteArray(Charsets.US_ASCII))
            header.put("fmt ".toByteArray(Charsets.US_ASCII))
            header.putInt(16)                      // fmt chunk size
            header.putShort(1.toShort())            // audio format: 1 = PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort(blockAlign.toShort())
            header.putShort(bitsPerSample.toShort())
            header.put("data".toByteArray(Charsets.US_ASCII))
            header.putInt(dataSize)
            fos.write(header.array())

            // write PCM data in reasonably sized chunks rather than one huge
            // buffer, to keep memory use sane for longer mangled clips
            val chunkSamples = 44100 // ~1 second per write for a 44.1kHz clip
            var i = 0
            while (i < samples.size) {
                val end = minOf(i + chunkSamples, samples.size)
                val buf = ByteBuffer.allocate((end - i) * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (j in i until end) buf.putShort(samples[j])
                fos.write(buf.array())
                i = end
            }
        }
    }
}
