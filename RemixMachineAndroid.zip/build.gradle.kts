// Top-level build file. If Android Studio prompts you to upgrade the
// Android Gradle Plugin / Kotlin plugin versions below on first sync,
// accept it -- these are pinned to what was current at the time this
// project was generated, and Studio's suggestion will be newer/correct.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
